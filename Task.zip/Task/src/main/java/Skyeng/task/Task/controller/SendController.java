package Skyeng.task.Task.controller;

import Skyeng.task.Task.service.SendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("api/")
public class SendController {

    @Autowired
    SendService sendService;

    public SendController(SendService sendService) {
        this.sendService = sendService;
    }

}

