package Skyeng.task.Task.service;

import Skyeng.task.Task.repository.PochtaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PochtaService {

    @Autowired
    PochtaRepository pochtaRepository;

    public PochtaService(PochtaRepository pochtaRepository) {
        this.pochtaRepository = pochtaRepository;
    }
}
