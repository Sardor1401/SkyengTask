package Skyeng.task.Task.repository;

import Skyeng.task.Task.model.PochtaSend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SendRepository extends JpaRepository<PochtaSend,Long> {

}
