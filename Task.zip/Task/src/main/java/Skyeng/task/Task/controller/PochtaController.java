package Skyeng.task.Task.controller;

import Skyeng.task.Task.service.PochtaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("api/")
public class PochtaController {

    @Autowired
    PochtaService pochtaService;

    public PochtaController(PochtaService pochtaService) {
        this.pochtaService = pochtaService;
    }


}
