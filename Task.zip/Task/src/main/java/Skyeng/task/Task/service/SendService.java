package Skyeng.task.Task.service;

import Skyeng.task.Task.repository.SendRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SendService {


    @Autowired
    SendRepository sendRepository;

    public SendService(SendRepository sendRepository) {
        this.sendRepository = sendRepository;
    }
}
