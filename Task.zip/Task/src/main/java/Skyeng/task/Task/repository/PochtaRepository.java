package Skyeng.task.Task.repository;

import Skyeng.task.Task.model.Pochta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PochtaRepository extends JpaRepository<Pochta,Long> {

}
